import { useEffect, useState, type ReactNode } from "react";

type Role = "Recepción" | "Producción" | "Control QC" | "Admin";
type Page = "registro" | "produccion" | "calidad" | "admin";
type IconName =
  | "camera"
  | "sun"
  | "moon"
  | "eye"
  | "eyeOff"
  | "chevron"
  | "clock"
  | "user"
  | "bell"
  | "plus"
  | "search"
  | "check"
  | "x"
  | "alert"
  | "image"
  | "users"
  | "settings"
  | "clipboard"
  | "printer";

const photoUrls = [
  "https://images.unsplash.com/photo-1536766768598-e09213fdcf22?auto=format&fit=crop&w=1000&q=85",
  "https://images.unsplash.com/photo-1568038479111-87bf80659645?auto=format&fit=crop&w=800&q=85",
  "https://images.unsplash.com/photo-1606143412458-acc5f86de897?auto=format&fit=crop&w=800&q=85",
];

function Icon({ name, size = 18 }: { name: IconName; size?: number }) {
  const paths: Record<IconName, ReactNode> = {
    camera: <><path d="M4 7h2.2l1.3-2h5l1.3 2H16a2 2 0 0 1 2 2v6a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2Z"/><circle cx="10" cy="12" r="3"/></>,
    sun: <><circle cx="10" cy="10" r="3"/><path d="M10 1v2M10 17v2M1 10h2M17 10h2M3.6 3.6 5 5M15 15l1.4 1.4M16.4 3.6 15 5M5 15l-1.4 1.4"/></>,
    moon: <path d="M17 12.5A7 7 0 0 1 7.5 3a7.2 7.2 0 1 0 9.5 9.5Z"/>,
    eye: <><path d="M2 10s3-5 8-5 8 5 8 5-3 5-8 5-8-5-8-5Z"/><circle cx="10" cy="10" r="2"/></>,
    eyeOff: <><path d="m3 3 14 14M8.5 5.2A8 8 0 0 1 10 5c5 0 8 5 8 5a13 13 0 0 1-2 2.6M6 6.2C3.5 7.6 2 10 2 10s3 5 8 5c.8 0 1.5-.1 2.2-.4"/><path d="M8.6 8.6a2 2 0 0 0 2.8 2.8"/></>,
    chevron: <path d="m6 8 4 4 4-4"/>,
    clock: <><circle cx="10" cy="10" r="8"/><path d="M10 5v5l3 2"/></>,
    user: <><circle cx="10" cy="7" r="3"/><path d="M4 18c.5-4 2.5-6 6-6s5.5 2 6 6"/></>,
    bell: <><path d="M5 8a5 5 0 0 1 10 0v4l2 2H3l2-2V8Z"/><path d="M8 17h4"/></>,
    plus: <path d="M10 4v12M4 10h12"/>,
    search: <><circle cx="9" cy="9" r="6"/><path d="m14 14 4 4"/></>,
    check: <path d="m4 10 4 4 8-8"/>,
    x: <path d="m5 5 10 10M15 5 5 15"/>,
    alert: <><path d="M10 2 2 17h16L10 2Z"/><path d="M10 7v4M10 14h.01"/></>,
    image: <><rect x="2" y="3" width="16" height="14" rx="2"/><circle cx="7" cy="8" r="1.5"/><path d="m3 15 4-4 3 3 2-2 5 5"/></>,
    users: <><circle cx="7" cy="7" r="3"/><circle cx="14.5" cy="8" r="2.5"/><path d="M1.5 18c.5-4 2.5-6 5.5-6s5 2 5.5 6M13 13c3 0 4.5 1.5 5 4"/></>,
    settings: <><circle cx="10" cy="10" r="3"/><path d="M10 2v2M10 16v2M2 10h2M16 10h2M4.3 4.3l1.4 1.4M14.3 14.3l1.4 1.4M15.7 4.3l-1.4 1.4M5.7 14.3l-1.4 1.4"/></>,
    clipboard: <><rect x="4" y="4" width="12" height="14" rx="2"/><path d="M7 4V2h6v2M7 9h6M7 13h4"/></>,
    printer: <><path d="M5 7V2h10v5M5 15H3V8h14v7h-2M5 12h10v6H5z"/></>,
  };
  return <svg aria-hidden="true" width={size} height={size} viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">{paths[name]}</svg>;
}

function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <div className="logo" aria-label="FotoStudio">
      <span className="logo-mark"><Icon name="camera" size={24} /></span>
      {!compact && <span className="logo-type">Foto<span>Studio</span></span>}
    </div>
  );
}

function ThemeToggle({ theme, onToggle, label = false }: { theme: "light" | "dark"; onToggle: () => void; label?: boolean }) {
  return (
    <button className="theme-toggle" onClick={onToggle} aria-label="Cambiar tema">
      <span className={theme === "light" ? "active" : ""}><Icon name="sun" size={15} /></span>
      <span className={theme === "dark" ? "active" : ""}><Icon name="moon" size={15} /></span>
      {label && <b>{theme === "light" ? "Tema claro" : "Tema oscuro"}</b>}
    </button>
  );
}

const roleMeta: Record<Role, { description: string; icon: IconName; home: Page; user: string }> = {
  Recepción: { description: "Registro y atención", icon: "clipboard", home: "registro", user: "Lucía Ramos" },
  Producción: { description: "Cola de trabajo", icon: "printer", home: "produccion", user: "Marco Díaz" },
  "Control QC": { description: "Inspección final", icon: "check", home: "calidad", user: "Sofía Castro" },
  Admin: { description: "Supervisión total", icon: "settings", home: "admin", user: "Diego Torres" },
};

function Login({ theme, toggleTheme, onLogin, initialRole = "Recepción", initialForgot = false, initialSent = false }: { theme: "light" | "dark"; toggleTheme: () => void; onLogin: (role: Role) => void; initialRole?: Role; initialForgot?: boolean; initialSent?: boolean }) {
  const [role, setRole] = useState<Role>(initialRole);
  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState("lucia@fotostudio.pe");
  const [password, setPassword] = useState("demo2025");
  const [forgot, setForgot] = useState(initialForgot);
  const [sent, setSent] = useState(initialSent);
  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email && password) onLogin(role);
  };
  return (
    <main className="login-page">
      <div className="login-top"><Logo /><ThemeToggle theme={theme} onToggle={toggleTheme} label /></div>
      <div className="login-shell">
        <section className="login-story">
          <div className="story-content">
            <span className="eyebrow">Sistema interno de operaciones</span>
            <h1>Del pedido a la entrega, todo en foco.</h1>
            <p>Gestiona cada etapa del estudio con precisión, visibilidad y confianza.</p>
            <div className="story-steps">
              <span><b>01</b> Registro</span><i /><span><b>02</b> Producción</span><i /><span><b>03</b> Calidad</span>
            </div>
          </div>
          <div className="aperture-art" aria-hidden="true"><span /><span /><span /></div>
        </section>
        <section className="login-card">
          <div className="login-heading">
            <span className="kicker">Bienvenido de nuevo</span>
            <h2>Accede a tu espacio</h2>
            <p>Selecciona tu rol para iniciar la experiencia de demostración.</p>
          </div>
          <form onSubmit={submit}>
            <fieldset>
              <legend>¿Cuál es tu rol?</legend>
              <div className="role-grid">
                {(Object.keys(roleMeta) as Role[]).map((item) => (
                  <button type="button" key={item} onClick={() => setRole(item)} className={`role-card ${role === item ? "selected" : ""}`}>
                    <span><Icon name={roleMeta[item].icon} /></span>
                    <b>{item}</b><small>{roleMeta[item].description}</small>
                    {role === item && <i><Icon name="check" size={12} /></i>}
                  </button>
                ))}
              </div>
            </fieldset>
            <label className="field">
              <span>Correo electrónico</span>
              <input value={email} onChange={(e) => setEmail(e.target.value)} type="email" placeholder="nombre@fotostudio.pe" />
            </label>
            <label className="field">
              <span>Contraseña</span>
              <div className="input-action">
                <input value={password} onChange={(e) => setPassword(e.target.value)} type={showPassword ? "text" : "password"} placeholder="Ingresa tu contraseña" />
                <button type="button" onClick={() => setShowPassword(!showPassword)}><Icon name={showPassword ? "eyeOff" : "eye"} /></button>
              </div>
            </label>
            <div className="form-meta"><label><input type="checkbox" defaultChecked /> Recordarme</label><button type="button" className="text-button" onClick={() => setForgot(true)}>¿Olvidaste tu contraseña?</button></div>
            <button className="primary wide" type="submit">Ingresar al sistema <span>→</span></button>
          </form>
          <footer>FotoStudio · Versión 2.4.0 · Entorno de demostración</footer>
        </section>
      </div>
      {forgot && (
        <div className="modal-backdrop" onMouseDown={() => setForgot(false)}>
          <div className="modal" onMouseDown={(e) => e.stopPropagation()}>
            <button className="icon-button close" onClick={() => setForgot(false)}><Icon name="x" /></button>
            <span className="modal-icon"><Icon name={sent ? "check" : "camera"} /></span>
            <h2>{sent ? "Revisa tu correo" : "Recuperar acceso"}</h2>
            <p>{sent ? "Mostramos esta confirmación como parte del prototipo; no se envió ningún correo real." : "Ingresa tu correo y simularemos el envío de instrucciones."}</p>
            {!sent && <><label className="field"><span>Correo electrónico</span><input type="email" defaultValue={email} /></label><button className="primary wide" onClick={() => setSent(true)}>Enviar instrucciones</button></>}
          </div>
        </div>
      )}
    </main>
  );
}

const orders = [
  { id: "FS-250184", client: "Valeria Mendoza", service: "Retrato editorial", priority: "URGENTE", time: "09:24", date: "18 JUN", tech: "Marco Díaz", size: "30 × 40 cm", state: "En impresión" },
  { id: "FS-250179", client: "Estudio Salazar", service: "Fotografía producto", priority: "URGENTE", time: "08:52", date: "18 JUN", tech: "Ana Torres", size: "20 × 30 cm", state: "Preparación" },
  { id: "FS-250176", client: "Daniela Costa", service: "Álbum de boda", priority: "URGENTE", time: "08:10", date: "18 JUN", tech: "Luis Peña", size: "25 × 25 cm", state: "En retoque" },
  { id: "FS-250172", client: "Gabriel Ruiz", service: "Retrato familiar", priority: "NORMAL", time: "11:05", date: "19 JUN", tech: "Marco Díaz", size: "20 × 25 cm", state: "Asignado" },
  { id: "FS-250168", client: "Luciana Vega", service: "Book profesional", priority: "NORMAL", time: "10:18", date: "19 JUN", tech: "Ana Torres", size: "A4", state: "Preparación" },
  { id: "FS-250163", client: "Casa Oliva", service: "Fotografía producto", priority: "NORMAL", time: "09:45", date: "20 JUN", tech: "Luis Peña", size: "15 × 20 cm", state: "En cola" },
  { id: "FS-250158", client: "María Paredes", service: "Restauración", priority: "BAJA", time: "16:20", date: "21 JUN", tech: "Ana Torres", size: "13 × 18 cm", state: "En cola" },
  { id: "FS-250151", client: "Grupo Norte", service: "Foto corporativa", priority: "BAJA", time: "15:40", date: "22 JUN", tech: "Marco Díaz", size: "10 × 15 cm", state: "En cola" },
];

function Header({ role, theme, toggleTheme, onLogout, menu, setMenu }: { role: Role; theme: "light" | "dark"; toggleTheme: () => void; onLogout: () => void; menu: boolean; setMenu: (v: boolean) => void }) {
  return (
    <header className="app-header">
      <Logo />
      <div className="header-actions">
        <div className="live-time"><Icon name="clock" size={16} /><span>10:42</span><small>LIM</small></div>
        <ThemeToggle theme={theme} onToggle={toggleTheme} />
        <button className="icon-button notification"><Icon name="bell" /><i /></button>
        <div className="user-wrap">
          <button className="user-chip" onClick={() => setMenu(!menu)}>
            <span>{roleMeta[role].user.split(" ").map((n) => n[0]).join("")}</span>
            <div><b>{roleMeta[role].user}</b><small>{role}</small></div><Icon name="chevron" size={14} />
          </button>
          {menu && <div className="user-menu">
            <div className="menu-profile"><span>{roleMeta[role].user.slice(0, 1)}</span><div><b>{roleMeta[role].user}</b><small>{role}</small></div></div>
            <button><Icon name="user" /> Mi perfil</button>
            <button onClick={toggleTheme}><Icon name={theme === "light" ? "moon" : "sun"} /> {theme === "light" ? "Tema oscuro" : "Tema claro"}</button>
            <button><Icon name="settings" /> Preferencias</button>
            <hr />
            <button onClick={onLogout}>Cerrar sesión <span>→</span></button>
          </div>}
        </div>
      </div>
    </header>
  );
}

function Nav({ role, page, setPage }: { role: Role; page: Page; setPage: (p: Page) => void }) {
  const allowed: { page: Page; label: string; icon: IconName }[] =
    role === "Recepción" ? [{ page: "registro", label: "Registro de Pedido", icon: "plus" }] :
    role === "Producción" ? [{ page: "produccion", label: "Dashboard de Producción", icon: "printer" }] :
    role === "Control QC" ? [{ page: "calidad", label: "Control de Calidad", icon: "check" }] :
    [{ page: "admin", label: "Resumen", icon: "clipboard" }, { page: "registro", label: "Registro", icon: "plus" }, { page: "produccion", label: "Producción", icon: "printer" }, { page: "calidad", label: "Control QC", icon: "check" }];
  return <nav className="main-nav">{allowed.map((item) => <button key={item.page} className={page === item.page ? "active" : ""} onClick={() => setPage(item.page)}><Icon name={item.icon} size={17} /><span>{item.label}</span></button>)}</nav>;
}

function SectionTitle({ number, title, description }: { number: string; title: string; description?: string }) {
  return <div className="section-title"><span>{number}</span><div><h3>{title}</h3>{description && <p>{description}</p>}</div></div>;
}

function Registration({ canNavigateProduction, onRegistered, initialSpecial = false, initialAdvanced = false, initialError = false }: { canNavigateProduction: boolean; onRegistered: () => void; initialSpecial?: boolean; initialAdvanced?: boolean; initialError?: boolean }) {
  const [special, setSpecial] = useState(initialSpecial);
  const [advanced, setAdvanced] = useState(initialAdvanced);
  const [client, setClient] = useState("");
  const [error, setError] = useState(initialError);
  const reset = () => { setClient(""); setSpecial(false); setAdvanced(false); setError(false); };
  const submit = (e: React.FormEvent) => { e.preventDefault(); if (!client) return setError(true); onRegistered(); };
  return (
    <div className="content-page">
      <div className="page-heading"><div><span className="eyebrow">Nuevo pedido</span><h1>Registro de Pedido</h1><p>Completa la información del cliente y las especificaciones de producción.</p></div><span className="secure-note"><Icon name="check" size={14} /> Registro interno</span></div>
      <form className="order-form" onSubmit={submit}>
        <section className="form-section">
          <SectionTitle number="01" title="Cliente & Servicio" description="Información principal para identificar el pedido." />
          <div className="form-grid two">
            <label className={`field ${error ? "error" : ""}`}><span>Nombre del cliente *</span><input value={client} onChange={(e) => { setClient(e.target.value); setError(false); }} placeholder="Ej. Valeria Mendoza" />{error && <small>Ingresa el nombre del cliente para continuar.</small>}</label>
            <label className="field"><span>Tipo de servicio *</span><select defaultValue=""><option value="" disabled>Selecciona un servicio</option><option>Retrato editorial</option><option>Fotografía de producto</option><option>Álbum fotográfico</option><option>Restauración</option></select></label>
          </div>
        </section>
        <section className="form-section">
          <SectionTitle number="02" title="Especificaciones de impresión" description="Define el formato final y los requisitos del trabajo." />
          <div className="form-grid three">
            <label className="field"><span>Tipo de papel *</span><select defaultValue=""><option value="" disabled>Selecciona el papel</option><option>Fotográfico brillante</option><option>Mate premium</option><option>Fine Art</option></select></label>
            <label className="field"><span>Tamaño de impresión *</span><select value={special ? "especial" : "30x40"} onChange={(e) => setSpecial(e.target.value === "especial")}><option value="30x40">30 × 40 cm</option><option value="20x30">20 × 30 cm</option><option value="especial">Tamaño especial</option></select></label>
            <label className="field"><span>Cantidad *</span><input type="number" min="1" defaultValue="1" /></label>
          </div>
          {special ? <><div className="info-band"><Icon name="alert" /><div><b>Tamaño especial seleccionado</b><p>Introduce las dimensiones exactas en centímetros.</p></div></div><div className="form-grid two"><label className="field"><span>Ancho (cm) *</span><input placeholder="Ej. 42.5" /></label><label className="field"><span>Alto (cm) *</span><input placeholder="Ej. 58.0" /></label></div></> :
            <label className="field"><span>Observaciones</span><textarea rows={3} placeholder="Detalles de color, encuadre o indicaciones para producción..." /></label>}
        </section>
        <section className={`advanced ${advanced ? "open" : ""}`}>
          <button type="button" onClick={() => setAdvanced(!advanced)}><div><span><Icon name="settings" /></span><div><b>Opciones avanzadas</b><small>Acabado, fecha de entrega y asignación</small></div></div><Icon name="chevron" /></button>
          {advanced && <div className="form-grid three advanced-fields"><label className="field"><span>Acabado especial</span><select><option>Sin acabado</option><option>Laminado mate</option><option>Enmarcado</option></select></label><label className="field"><span>Fecha de entrega</span><input type="date" defaultValue="2025-06-20" /></label><label className="field"><span>Técnico asignado</span><select><option>Asignación automática</option><option>Marco Díaz</option><option>Ana Torres</option></select></label></div>}
        </section>
        <div className="form-actions"><button type="button" className="secondary" onClick={reset}>Limpiar</button><button className="primary" type="submit">Registrar Pedido <span>→</span></button></div>
      </form>
      {!canNavigateProduction && <p className="permission-note"><Icon name="alert" size={15} /> Tras registrar, Recepción permanece en su módulo por política de acceso.</p>}
    </div>
  );
}

function Stats() {
  return <div className="stats-grid">
    {[["En cola", "08", "+2 desde ayer", "clipboard"], ["Urgentes", "03", "Requieren atención", "alert"], ["Completados hoy", "12", "Meta diaria: 18", "check"], ["Tiempo promedio", "2h 18m", "−12 min esta semana", "clock"]].map(([label, value, note, icon], i) =>
      <article className={`stat-card s${i}`} key={label}><div><span>{label}</span><strong>{value}</strong><small>{note}</small></div><i><Icon name={icon as IconName} /></i></article>)}
  </div>;
}

function OrderCard({ order, onClick }: { order: typeof orders[number]; onClick: () => void }) {
  return <button className="order-card" onClick={onClick}>
    <div className="order-card-top"><span className={`priority ${order.priority.toLowerCase()}`}>{order.priority === "URGENTE" && <Icon name="alert" size={11} />}{order.priority}</span><span className="order-time">{order.date} · {order.time}</span></div>
    <h3>{order.client}</h3><code>{order.id}</code><p>{order.service}</p>
    <div className="order-meta"><span><small>Técnico</small>{order.tech}</span><span><small>Formato</small>{order.size}</span></div>
    <footer><span className="state-dot" />{order.state}<b>Ver detalle →</b></footer>
  </button>;
}

function Dashboard({ role, toast, setToast, initialFilter = "Todos", initialSelected = false, initialCorrection = false }: { role: Role; toast: string; setToast: (v: string) => void; initialFilter?: string; initialSelected?: boolean; initialCorrection?: boolean }) {
  const [filter, setFilter] = useState(initialFilter);
  const [selected, setSelected] = useState<typeof orders[number] | null>(initialSelected ? orders[0] : null);
  const [correction, setCorrection] = useState(initialCorrection);
  const visible = filter === "Todos" ? orders : orders.filter((o) => o.priority === (filter === "Urgentes" ? "URGENTE" : "NORMAL"));
  const approve = () => { setSelected(null); setToast(role === "Producción" ? "Etapa de producción actualizada correctamente" : "Pedido aprobado y listo para entrega"); };
  return (
    <div className="content-page">
      <div className="page-heading dashboard-heading"><div><span className="eyebrow">Operaciones en tiempo real</span><h1>Dashboard de Producción</h1><p>Supervisa la cola de trabajo y las entregas del estudio.</p></div><button className="secondary"><Icon name="search" /> Buscar pedido</button></div>
      <Stats />
      <div className="queue-header"><div><h2>Cola de producción</h2><p>Haz clic en una tarjeta para ver el detalle del pedido.</p></div><div className="filter-group">{["Todos", "Urgentes", "Normales"].map((f) => <button key={f} className={filter === f ? "active" : ""} onClick={() => setFilter(f)}>{f}{f === "Todos" && <span>8</span>}</button>)}</div></div>
      <div className="orders-grid">{visible.map((o) => <OrderCard key={o.id} order={o} onClick={() => setSelected(o)} />)}</div>
      {selected && <DetailDrawer order={selected} role={role} onClose={() => setSelected(null)} onApprove={approve} onCorrection={() => setCorrection(true)} />}
      {correction && <CorrectionModal onClose={() => setCorrection(false)} onConfirm={() => { setCorrection(false); setSelected(null); setToast("Corrección solicitada a Producción"); }} />}
      {toast && <Toast message={toast} onClose={() => setToast("")} />}
    </div>
  );
}

function DetailDrawer({ order, role, onClose, onApprove, onCorrection }: { order: typeof orders[number]; role: Role; onClose: () => void; onApprove: () => void; onCorrection: () => void }) {
  const production = role === "Producción";
  return <div className="drawer-backdrop" onMouseDown={onClose}><aside className="drawer" onMouseDown={(e) => e.stopPropagation()}>
    <header><div><span className="eyebrow">Detalle del pedido</span><h2>{order.client}</h2><code>{order.id}</code></div><button className="icon-button" onClick={onClose}><Icon name="x" /></button></header>
    <div className="preview"><img src={photoUrls[0]} alt="Retrato editorial cálido de referencia para el pedido" /><span><Icon name="image" /> Vista previa del pedido</span></div>
    <div className="drawer-block"><h3>Información</h3><div className="spec-grid"><span><small>Servicio</small>{order.service}</span><span><small>Prioridad</small><b className={`priority ${order.priority.toLowerCase()}`}>{order.priority}</b></span><span><small>Dimensiones</small>{order.size}</span><span><small>Técnico</small>{order.tech}</span><span><small>Papel</small>Mate premium</span><span><small>Entrega</small>20 Jun · 17:00</span></div></div>
    <div className="observation"><b>Observaciones del cliente</b><p>Conservar tonos cálidos de piel y un acabado mate sin bordes. Revisar detalle de sombras antes de imprimir.</p></div>
    <div className="drawer-block"><h3>Trazabilidad resumida</h3><div className="mini-timeline">{["Pedido creado", "Asignado", production ? "En impresión" : "Inspección de calidad", "Entrega pendiente"].map((step, i) => <div className={i < 2 ? "done" : i === 2 ? "current" : ""} key={step}><i>{i < 2 ? <Icon name="check" size={11} /> : ""}</i><span>{step}</span></div>)}</div></div>
    <div className="drawer-actions"><button className="primary" onClick={onApprove}><Icon name={production ? "printer" : "check"} />{production ? "Marcar impresión completada" : "Confirmar Aprobación"}</button><button className="secondary danger" onClick={onCorrection}>Solicitar corrección</button></div>
  </aside></div>;
}

function CorrectionModal({ onClose, onConfirm }: { onClose: () => void; onConfirm: () => void }) {
  return <div className="modal-backdrop" onMouseDown={onClose}><div className="modal correction-modal" onMouseDown={(e) => e.stopPropagation()}>
    <button className="icon-button close" onClick={onClose}><Icon name="x" /></button><span className="modal-icon warning"><Icon name="alert" /></span><h2>Solicitar corrección</h2><p>Describe con precisión el ajuste requerido. El pedido volverá a la etapa de producción.</p>
    <label className="field"><span>Motivo de la corrección *</span><select><option>Ajuste de color</option><option>Problema de impresión</option><option>Encuadre o dimensiones</option></select></label>
    <label className="field"><span>Descripción</span><textarea rows={4} placeholder="Ej. Reducir dominante cálida en los tonos de piel..." /></label>
    <div className="modal-actions"><button className="secondary" onClick={onClose}>Cancelar</button><button className="primary danger-fill" onClick={onConfirm}>Enviar solicitud</button></div>
  </div></div>;
}

function Quality({ setToast, initialCorrection = false, initialApproved = false }: { setToast: (v: string) => void; initialCorrection?: boolean; initialApproved?: boolean }) {
  const [correction, setCorrection] = useState(initialCorrection);
  const [approved, setApproved] = useState(initialApproved);
  const approve = () => { setApproved(true); setToast("Calidad aprobada: pedido listo para entrega"); };
  const timeline = [
    ["Pedido creado", "18 Jun · 08:42", "Lucía Ramos", "Datos y archivos recibidos"],
    ["Asignado a producción", "18 Jun · 09:05", "Marco Díaz", "Técnico notificado"],
    ["Retoque y preparación", "18 Jun · 11:30", "Marco Díaz", "Ajustes de color completados"],
    ["Impresión completada", "18 Jun · 14:18", "Marco Díaz", "Salida en papel mate premium"],
    [approved ? "Calidad aprobada" : "Inspección de calidad", approved ? "Ahora" : "18 Jun · 15:02", "Sofía Castro", approved ? "Pedido listo para entrega" : "Revisión visual en curso"],
    ["Entrega al cliente", "20 Jun · 17:00", "Recepción", "Pendiente de confirmación"],
  ];
  return <div className="content-page qc-page">
    <div className="page-heading"><div><span className="eyebrow">Estación de inspección</span><h1>Control de Calidad</h1><p>Valida especificaciones, acabado y trazabilidad antes de la entrega.</p></div><span className={`review-chip ${approved ? "approved" : ""}`}><i />{approved ? "Aprobado · Listo para entrega" : "En revisión de calidad"}</span></div>
    <div className="qc-layout">
      <section className="qc-main card-surface">
        <div className="qc-order-title"><div><h2>Valeria Mendoza</h2><code>FS-250184</code></div><span className="priority urgente"><Icon name="alert" size={11} /> URGENTE</span></div>
        <div className="gallery">{photoUrls.map((url, i) => <button key={url} className={i === 0 ? "featured" : ""}><img src={url} alt={`Referencia fotográfica ${i + 1} del pedido`} />{i === 0 && <span>Principal</span>}</button>)}</div>
        <div className="qc-section"><h3>Especificaciones del pedido</h3><div className="spec-grid qc-specs">{[["Servicio", "Retrato editorial"], ["Prioridad", "Urgente"], ["Tipo de papel", "Mate premium"], ["Tamaño", "30 × 40 cm"], ["Cantidad", "2 copias"], ["Acabado", "Sin laminado"]].map(([a,b]) => <span key={a}><small>{a}</small>{b}</span>)}</div></div>
        <div className="observation"><b>Observaciones</b><p>“Conservar tonos cálidos de piel y acabado mate. No aplicar recorte adicional.”</p></div>
        <div className="people-grid">{[["Técnico asignado", "MD", "Marco Díaz"], ["Inspector QC", "SC", "Sofía Castro"], ["Fecha de entrega", "20", "Jun · 17:00"], ["Tiempo en sistema", "6h", "20 minutos"]].map(([l,a,v]) => <div key={l}><span>{a}</span><p><small>{l}</small><b>{v}</b></p></div>)}</div>
        <div className="quality-actions"><button className="primary approve" onClick={approve} disabled={approved}><Icon name="check" />{approved ? "Calidad aprobada" : "Confirmar Aprobación"}</button><button className="secondary danger" onClick={() => setCorrection(true)} disabled={approved}>Solicitar corrección</button></div>
      </section>
      <aside className="timeline-card card-surface"><div className="timeline-heading"><span><Icon name="clock" /></span><div><h2>Trazabilidad del pedido</h2><p>Historial completo de producción</p></div></div><div className="timeline">{timeline.map(([step,date,person,desc], i) => <div className={`${i < 4 || approved && i === 4 ? "done" : i === 4 ? "current" : "pending"}`} key={step}><i>{i < 4 || approved && i === 4 ? <Icon name="check" size={12} /> : ""}</i><div><h3>{step}</h3><small>{date}</small><b>{person}</b><p>{desc}</p></div></div>)}</div></aside>
    </div>
    {correction && <CorrectionModal onClose={() => setCorrection(false)} onConfirm={() => { setCorrection(false); setToast("Corrección solicitada a Producción"); }} />}
  </div>;
}

function AdminHome({ setPage }: { setPage: (p: Page) => void }) {
  return <div className="content-page"><div className="page-heading"><div><span className="eyebrow">Visión general</span><h1>Buenos días, Diego</h1><p>Este es el pulso operativo de FotoStudio para hoy.</p></div><button className="primary" onClick={() => setPage("registro")}><Icon name="plus" /> Nuevo pedido</button></div><Stats />
    <div className="admin-grid"><section className="card-surface"><div className="queue-header"><div><h2>Accesos rápidos</h2><p>Módulos bajo tu supervisión</p></div></div><div className="quick-links"><button onClick={() => setPage("registro")}><span><Icon name="clipboard" /></span><div><b>Registrar pedido</b><small>Crear una nueva orden</small></div>→</button><button onClick={() => setPage("produccion")}><span><Icon name="printer" /></span><div><b>Supervisar producción</b><small>8 pedidos en cola</small></div>→</button><button onClick={() => setPage("calidad")}><span><Icon name="check" /></span><div><b>Control de calidad</b><small>3 inspecciones pendientes</small></div>→</button><button><span><Icon name="users" /></span><div><b>Usuarios y roles</b><small>12 usuarios activos</small></div>→</button></div></section>
      <section className="card-surface workload"><div className="queue-header"><div><h2>Carga por técnico</h2><p>Asignaciones activas</p></div></div>{[["Marco Díaz", 7, "78%"], ["Ana Torres", 5, "56%"], ["Luis Peña", 3, "34%"]].map(([name,n,p]) => <div key={name}><span><b>{name}</b><small>{n} pedidos</small></span><i><b style={{ width: p }} /></i></div>)}</section></div>
  </div>;
}

function Toast({ message, onClose }: { message: string; onClose: () => void }) {
  useEffect(() => {
    const snapshot = new URLSearchParams(window.location.search).has("screen");
    if (snapshot) return;
    const t = setTimeout(onClose, 4000);
    return () => clearTimeout(t);
  }, [onClose]);
  return <div className="toast"><span><Icon name="check" /></span><div><b>Operación completada</b><p>{message}</p></div><button onClick={onClose}><Icon name="x" size={15} /></button></div>;
}

type FlowScreen = {
  id: string;
  title: string;
  path: string;
  connection: string;
};

const flowScreens: FlowScreen[] = [
  { id: "login", title: "Acceso · Recepción", path: "login", connection: "Inicio del flujo" },
  { id: "login-produccion", title: "Acceso · Producción", path: "login-produccion", connection: "Seleccionar rol Producción" },
  { id: "login-calidad", title: "Acceso · Control QC", path: "login-calidad", connection: "Seleccionar rol Control QC" },
  { id: "login-admin", title: "Acceso · Admin", path: "login-admin", connection: "Seleccionar rol Admin" },
  { id: "forgot", title: "Recuperar acceso", path: "forgot", connection: "¿Olvidaste tu contraseña?" },
  { id: "forgot-sent", title: "Confirmación de recuperación", path: "forgot-sent", connection: "Enviar instrucciones" },
  { id: "admin", title: "Resumen de administración", path: "admin", connection: "Ingresar como Admin" },
  { id: "menu", title: "Menú de usuario", path: "menu", connection: "Perfil, tema, preferencias y cierre de sesión" },
  { id: "registro", title: "Registro de pedido", path: "registro", connection: "Rol Recepción o pestaña Registro" },
  { id: "registro-special", title: "Tamaño especial", path: "registro-special", connection: "Seleccionar “Tamaño especial”" },
  { id: "registro-advanced", title: "Opciones avanzadas", path: "registro-advanced", connection: "Abrir Opciones avanzadas" },
  { id: "registro-error", title: "Validación del formulario", path: "registro-error", connection: "Registrar sin nombre de cliente" },
  { id: "registro-ok", title: "Pedido registrado", path: "registro-ok", connection: "Completar datos y registrar pedido" },
  { id: "produccion", title: "Producción · Todos", path: "produccion", connection: "Registrar pedido o pestaña Producción" },
  { id: "produccion-urgentes", title: "Producción · Urgentes", path: "produccion-urgentes", connection: "Pestaña Urgentes" },
  { id: "produccion-normales", title: "Producción · Normales", path: "produccion-normales", connection: "Pestaña Normales" },
  { id: "detalle", title: "Detalle del pedido", path: "detalle", connection: "Seleccionar cualquier pedido" },
  { id: "correccion", title: "Solicitar corrección", path: "correccion", connection: "Solicitar corrección" },
  { id: "correccion-enviada", title: "Corrección enviada", path: "correccion-enviada", connection: "Enviar solicitud" },
  { id: "produccion-ok", title: "Producción completada", path: "produccion-ok", connection: "Marcar impresión completada" },
  { id: "calidad", title: "Control de calidad", path: "calidad", connection: "Rol Control QC o pestaña Control QC" },
  { id: "calidad-correccion", title: "Corrección desde calidad", path: "calidad-correccion", connection: "Solicitar corrección" },
  { id: "calidad-correccion-enviada", title: "Corrección QC enviada", path: "calidad-correccion-enviada", connection: "Enviar solicitud" },
  { id: "calidad-ok", title: "Calidad aprobada", path: "calidad-ok", connection: "Confirmar aprobación · Listo para entrega" },
];

const flowDevices = [
  { id: "pc", title: "PC", viewport: "1440 × 900" },
  { id: "tablet", title: "Tablet", viewport: "768 × 1024" },
  { id: "mobile", title: "Celular", viewport: "390 × 844" },
];

function FlowMap() {
  return (
    <main className="flow-map">
      <header className="flow-header">
        <div><span className="eyebrow">Mapa de navegación completo</span><p className="flow-title">FotoStudio · User flow</p><p>Las pantallas se muestran intactas dentro de su viewport original. Las flechas documentan cada transición, pestaña y paso disponible.</p></div>
        <div className="flow-legend"><span><i /> Pantalla</span><span><b>↓</b> Acción / transición</span></div>
      </header>
      <section className="flow-board" aria-label="Flujo por dispositivo">
        {flowDevices.map((device) => (
          <section className={`flow-column ${device.id}`} key={device.id}>
            <header><span>{device.title}</span><small>{device.viewport}</small></header>
            <div className="flow-track">
              {flowScreens.map((screen, index) => (
                <article className="flow-node" key={screen.id}>
                  {index > 0 && <div className="flow-connector"><span>{screen.connection}</span><i /></div>}
                  <div className="flow-node-heading"><span>{String(index + 1).padStart(2, "0")}</span><div><b>{screen.title}</b><small>{screen.id}</small></div></div>
                  <div className="flow-preview">
                    <iframe loading="lazy" tabIndex={-1} title={`${screen.title} en ${device.title}`} src={`?screen=${screen.path}&device=${device.id}`} />
                  </div>
                </article>
              ))}
            </div>
          </section>
        ))}
      </section>
    </main>
  );
}

export default function App() {
  const params = new URLSearchParams(window.location.search);
  const screen = params.get("screen");
  if (!screen) return <FlowMap />;

  const loginScreen = screen.startsWith("login") || screen === "forgot" || screen === "forgot-sent";
  const initialPage: Page = screen === "admin" || screen === "menu" ? "admin" : screen.startsWith("registro") ? "registro" : screen.startsWith("calidad") ? "calidad" : "produccion";
  const initialRole: Role | null = loginScreen ? null : initialPage === "admin" || screen === "menu" ? "Admin" : initialPage === "registro" ? "Recepción" : initialPage === "calidad" ? "Control QC" : "Producción";
  const [theme, setTheme] = useState<"light" | "dark">("light");
  const [role, setRole] = useState<Role | null>(initialRole);
  const [page, setPage] = useState<Page>(initialPage);
  const [menu, setMenu] = useState(screen === "menu");
  const initialToast =
    screen === "registro-ok" ? "Pedido FS-250185 registrado correctamente" :
    screen === "produccion-ok" ? "Etapa de producción actualizada correctamente" :
    screen === "correccion-enviada" || screen === "calidad-correccion-enviada" ? "Corrección solicitada a Producción" :
    screen === "calidad-ok" ? "Calidad aprobada: pedido listo para entrega" : "";
  const [toast, setToast] = useState(initialToast);
  useEffect(() => { document.documentElement.dataset.theme = theme; }, [theme]);
  const toggleTheme = () => setTheme((t) => t === "light" ? "dark" : "light");
  const login = (r: Role) => { setRole(r); setPage(roleMeta[r].home); };
  const selectedLoginRole: Role =
    screen === "login-produccion" ? "Producción" :
    screen === "login-calidad" ? "Control QC" :
    screen === "login-admin" ? "Admin" : "Recepción";
  if (!role) return <Login theme={theme} toggleTheme={toggleTheme} onLogin={login} initialRole={selectedLoginRole} initialForgot={screen === "forgot" || screen === "forgot-sent"} initialSent={screen === "forgot-sent"} />;
  return <div className="app-shell" onClick={() => menu && setMenu(false)}>
    <Header role={role} theme={theme} toggleTheme={toggleTheme} onLogout={() => setRole(null)} menu={menu} setMenu={setMenu} />
    <Nav role={role} page={page} setPage={setPage} />
    <main>
      {page === "registro" && <Registration canNavigateProduction={role === "Admin"} initialSpecial={screen === "registro-special"} initialAdvanced={screen === "registro-advanced"} initialError={screen === "registro-error"} onRegistered={() => { setToast("Pedido FS-250185 registrado correctamente"); if (role === "Admin") setPage("produccion"); }} />}
      {page === "produccion" && <Dashboard role={role} toast={toast} setToast={setToast} initialFilter={screen === "produccion-urgentes" ? "Urgentes" : screen === "produccion-normales" ? "Normales" : "Todos"} initialSelected={screen === "detalle" || screen === "correccion"} initialCorrection={screen === "correccion"} />}
      {page === "calidad" && <Quality setToast={setToast} initialCorrection={screen === "calidad-correccion"} initialApproved={screen === "calidad-ok"} />}
      {page === "admin" && <AdminHome setPage={setPage} />}
    </main>
    {toast && page !== "produccion" && <Toast message={toast} onClose={() => setToast("")} />}
  </div>;
}
